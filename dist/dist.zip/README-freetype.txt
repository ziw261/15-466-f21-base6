Freetype used under the provisions of the FTL.

Portions of this software are copyright © 2020 The FreeType Project (www.freetype.org).  All rights reserved.
